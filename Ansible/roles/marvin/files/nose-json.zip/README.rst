nose-json
=========

Outputs test results in a consumable JSON format.

Usage
-----

::

    nosetests --with-json --json-file="nosetests.json"
